const employerListDeleteEvent = new CustomEvent("employerlistdeleteevent", {
            detail: {name: "Delete"}
        });

export default employerListDeleteEvent		//to ../fetchingData/getemployerList.js