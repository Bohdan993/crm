
	const storageVacancyClientsUpdate = new CustomEvent("storageupdate", {
            detail: {name: 'Storage update'}
        });


	export default storageVacancyClientsUpdate 		//to ../Components/Vacancy/VacancyRow.js