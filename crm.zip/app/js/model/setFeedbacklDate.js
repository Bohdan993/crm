

const setFeedbackDate = (input) => {
	input.value = new Date().toLocaleDateString()
}


export default setFeedbackDate