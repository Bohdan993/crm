import StorageGlobalEmployersVacancies from './Employers-VacanciesStorageClass.js'



const storage = new StorageGlobalEmployersVacancies()

export default storage