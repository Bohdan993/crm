

const addFeedbackForm = (btn, block) => {
	btn.addEventListener('click', function(){
		block.style.display = 'block'
	})
}


export default addFeedbackForm