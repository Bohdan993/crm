const employerListUpdateEvent = new CustomEvent("employerslistupdateevent", {
          detail: {name: 'Update'}
      });


export default employerListUpdateEvent 		//to ../Components/Employer/EmployerList.js