const vacancyListUpdateFetchEvent = new CustomEvent("vacancylistupdatefetchevent", {
          detail: {name: 'Update'}
      });


export default vacancyListUpdateFetchEvent 		//to ../Components/vacancy/vacancyList.js