const employerModalCloseEvent = new CustomEvent("employermodalcloseeevent", {
          detail: {name: 'Closed'}
      });


export default employerModalCloseEvent		//to ../Components/Employer/EmployerList.js