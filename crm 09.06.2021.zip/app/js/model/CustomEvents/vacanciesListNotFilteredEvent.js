const vacanciesListNotFiltered = new CustomEvent("vacancieslistnotfiltered", {
            detail: {name: "NotFiltered"}
        });

export default vacanciesListNotFiltered 		//to ../fetchingData/getVacancyList