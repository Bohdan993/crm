
	const storageVacancyEmployerDataAdd = new CustomEvent("storageemployeradd", {
            detail: {name: 'Data add'}
        });


	export default storageVacancyEmployerDataAdd 		//to ../Components/Vacancy/VacancyModal/FindEmployerPopupComponent