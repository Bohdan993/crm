const vacancyModalCloseEvent = new CustomEvent("vacancymodalcloseeevent", {
          detail: {name: 'Closed'}
      });


export default vacancyModalCloseEvent		//to ../Components/vacancy/vacancyList.js