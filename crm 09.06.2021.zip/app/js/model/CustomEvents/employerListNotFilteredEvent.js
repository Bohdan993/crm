const employerListNotFiltered = new CustomEvent("employerlistnotfiltered", {
            detail: {name: "NotFiltered"}
        });

export default employerListNotFiltered 		//to ../fetchingData/getEmployersList