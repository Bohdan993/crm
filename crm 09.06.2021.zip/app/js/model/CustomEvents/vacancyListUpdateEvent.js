const vacancyListUpdateEvent = new CustomEvent("vacancylistupdateevent", {
          detail: {name: 'Update'}
      });


export default vacancyListUpdateEvent 		//to ../Components/vacancy/vacancyList.js