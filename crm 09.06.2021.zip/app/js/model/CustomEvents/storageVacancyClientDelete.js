
	const storageVacancyClientDelete = new CustomEvent("storagedelete", {
            detail: {name: 'Storage delete'}
        });


	export default storageVacancyClientDelete 		//to ../vacancy/switchRowStatuses